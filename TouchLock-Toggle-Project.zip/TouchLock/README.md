# TouchLock — Android

Prototype Android natif Kotlin : une couche transparente intercepte les touchers, laisse la vidéo visible et affiche un bouton cadenas flottant. Un appui sur le cadenas retire la couche et réactive les interactions.

## Construire l’APK
1. Installer Android Studio (version récente) et Android SDK 35.
2. Ouvrir le dossier `TouchLock` dans Android Studio.
3. Laisser Gradle synchroniser le projet.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK : `app/build/outputs/apk/debug/app-debug.apk`.

## Première utilisation
1. Installer l’APK et ouvrir TouchLock.
2. Autoriser « Afficher par-dessus les autres applications ».
3. Revenir dans Messenger / lecteur vidéo.
4. Activer TouchLock depuis l’application avant de lancer la vidéo, ou revenir à TouchLock puis activer.
5. Le cercle cadenas est déplaçable. Appuyer dessus retire le voile tactile.

## Limites connues
- Prototype à tester sur le modèle Android exact et avec les applications utilisées.
- La couche bloque les gestes tactiles dans la zone d’affichage, y compris certains gestes système selon le fabricant. Le bouton flottant reste le moyen de sortie.
- Le bouton d’alimentation et les touches physiques ne sont pas bloqués.
- Le service utilise un foreground service « special use » et une permission d’affichage superposé ; une publication Google Play demanderait une justification et une validation de politique.
- L’overlay est transparent : la vidéo et l’appel restent visibles, mais les gestes tactiles ne passent pas à l’application en dessous.


## Compiler dans le cloud (sans installer AndroidIDE)
Le dépôt contient `.github/workflows/android-apk.yml`.
1. Créer un dépôt GitHub vide et y téléverser le contenu du dossier `TouchLock` (pas le ZIP lui-même).
2. Ouvrir l'onglet **Actions** du dépôt et sélectionner **Build TouchLock APK**.
3. Appuyer sur **Run workflow** si le workflow ne démarre pas automatiquement.
4. À la fin du job, télécharger l'artefact **TouchLock-debug-apk** depuis la page d'exécution.
5. Extraire `app-debug.apk` et l'installer sur le téléphone pour un test.

Cette compilation produit un APK debug non destiné à une publication Play Store. Le workflow compile le code ; il ne constitue pas une validation fonctionnelle. Tester les permissions et le comportement sur l'appareil avant usage régulier.
