package fr.touchlock

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.os.Build

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(18, 22, 30))
        }
        val title = TextView(this).apply {
            text = "TouchLock"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val intro = TextView(this).apply {
            text = "Verrouille les touches tout en laissant la vidéo visible.\n\nAutorise l’affichage par-dessus les autres applications, puis active le verrouillage."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 28)
        }
        val permission = Button(this).apply {
            text = "Autoriser l’affichage par-dessus"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val start = Button(this).apply {
            text = "Activer le verrouillage tactile"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(this@MainActivity, TouchLockService::class.java).setAction(TouchLockService.ACTION_LOCK)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    status.text = "TouchLock actif. Le cercle flottant permet de déverrouiller les touches."
                } else {
                    status.text = "Autorisation nécessaire : active d’abord l’affichage par-dessus."
                }
            }
        }
        val stop = Button(this).apply {
            text = "Arrêter TouchLock"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TouchLockService::class.java))
                status.text = "TouchLock arrêté."
            }
        }
        status = TextView(this).apply {
            text = "État : inactif"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }
        layout.addView(title)
        layout.addView(intro)
        layout.addView(permission)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(status)
        setContentView(layout)
    }
}
