package fr.touchlock

import android.app.*
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Path
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import kotlin.math.abs

class TouchLockService : Service() {
    companion object {
        const val ACTION_LOCK = "fr.touchlock.LOCK"
        private const val CHANNEL = "touchlock_status"
        private const val NOTIFICATION_ID = 41
    }

    private lateinit var wm: WindowManager
    private var shield: TouchShield? = null
    private var button: FloatingLockButton? = null
    private var locked = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        if (button == null) {
            button = FloatingLockButton()
            val size = dp(60f).toInt()
            val bp = WindowManager.LayoutParams(
                size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = dp(24f).toInt()
                y = (resources.displayMetrics.heightPixels * 0.65f).toInt()
            }
            wm.addView(button, bp)
        }
        setLocked(true)
        return START_STICKY
    }

    private fun setLocked(value: Boolean) {
        locked = value
        if (value && shield == null) {
            shield = TouchShield()
            val sp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            wm.addView(shield, sp)
            // Keep the button above the touch shield.
            button?.let { b ->
                try { wm.removeView(b) } catch (_: Exception) {}
                val size = dp(60f).toInt()
                val bp = WindowManager.LayoutParams(
                    size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = buttonX
                    y = buttonY
                }
                wm.addView(b, bp)
            }
        } else if (!value && shield != null) {
            try { wm.removeView(shield) } catch (_: Exception) {}
            shield = null
        }
        button?.invalidate()
    }

    private var buttonX = dp(24f).toInt()
    private var buttonY = (resources.displayMetrics.heightPixels * 0.65f).toInt()

    private inner class TouchShield : View(this@TouchLockService) {
        override fun onTouchEvent(event: MotionEvent): Boolean = true
    }

    private inner class FloatingLockButton : View(this@TouchLockService) {
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB3222630.toInt() }
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2f)
        }
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2.5f)
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        private var downX = 0f
        private var downY = 0f
        private var originX = 0
        private var originY = 0
        private var moved = false
        private var downAt = 0L

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val cx = width / 2f
            val cy = height / 2f
            val r = dp(27f)
            c.drawCircle(cx, cy, r, bg)
            c.drawCircle(cx, cy, r, stroke)
            val w = dp(10f)
            val top = cy - dp(2f)
            val left = cx - w
            val right = cx + w
            val bottom = cy + dp(12f)
            // Body of padlock
            c.drawRoundRect(left, top, right, bottom, dp(2f), dp(2f), p)
            val path = Path()
            if (locked) {
                path.moveTo(left + dp(1f), top)
                path.lineTo(left + dp(1f), top - dp(5f))
                path.quadTo(cx, top - dp(17f), right - dp(1f), top - dp(5f))
                path.lineTo(right - dp(1f), top)
            } else {
                path.moveTo(left + dp(1f), top)
                path.lineTo(left + dp(1f), top - dp(5f))
                path.quadTo(cx, top - dp(17f), right - dp(1f), top - dp(5f))
            }
            c.drawPath(path, p)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    originX = buttonX; originY = buttonY
                    downAt = System.currentTimeMillis()
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) + abs(dy) > dp(10f)) moved = true
                    if (moved) {
                        buttonX = (originX + dx).coerceIn(0, resources.displayMetrics.widthPixels - width)
                        buttonY = (originY + dy).coerceIn(0, resources.displayMetrics.heightPixels - height)
                        (layoutParams as? WindowManager.LayoutParams)?.let {
                            it.x = buttonX; it.y = buttonY
                            wm.updateViewLayout(this, it)
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved && System.currentTimeMillis() - downAt < 700) setLocked(!locked)
                    invalidate()
                    return true
                }
            }
            return true
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "TouchLock", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, TouchLockService::class.java).setAction("STOP"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("TouchLock actif")
            .setContentText("Le bouton flottant bascule entre verrouillé et déverrouillé.")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Arrêter", stop).build())
            .build()
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onDestroy() {
        shield?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        button?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        shield = null
        button = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
