package fr.touchlock

import android.app.*
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView

class TouchLockService : Service() {
    companion object {
        const val ACTION_LOCK = "fr.touchlock.LOCK"
        private const val CHANNEL = "touchlock_status"
        private const val NOTIFICATION_ID = 41
    }

    private lateinit var windowManager: WindowManager
    private var overlay: LockOverlay? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            unlockTouches()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        showOverlay()
        return START_STICKY
    }

    private fun showOverlay() {
        if (overlay != null) return
        val view = LockOverlay()
        overlay = view
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        windowManager.addView(view, params)
    }

    private inner class LockOverlay : View(this) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB3222630.toInt() }
        private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2f)
        }
        private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = dp(25f); textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        private val bubbleRadius = dp(29f)
        private var bubbleX = 0f
        private var bubbleY = 0f
        private var downX = 0f
        private var downY = 0f
        private var startX = 0f
        private var startY = 0f
        private var dragging = false

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (bubbleX == 0f) {
                bubbleX = width - dp(48f)
                bubbleY = height * 0.72f
            }
            // Le voile est entièrement transparent : la vidéo reste visible.
            canvas.drawCircle(bubbleX, bubbleY, bubbleRadius, fill)
            canvas.drawCircle(bubbleX, bubbleY, bubbleRadius, outline)
            canvas.drawText("🔒", bubbleX, bubbleY + dp(9f), icon)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = bubbleX; startY = bubbleY
                    dragging = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(8f)) dragging = true
                    if (dragging) {
                        bubbleX = (startX + dx).coerceIn(bubbleRadius + dp(8f), width - bubbleRadius - dp(8f))
                        bubbleY = (startY + dy).coerceIn(bubbleRadius + dp(8f), height - bubbleRadius - dp(8f))
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) unlockTouches()
                    return true
                }
            }
            return true
        }
    }

    private fun unlockTouches() {
        overlay?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlay = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "TouchLock", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, TouchLockService::class.java).setAction("STOP"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("TouchLock actif")
            .setContentText("Touchez le cadenas flottant pour réactiver l’écran tactile.")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Arrêter", stopIntent).build())
            .build()
    }

    private fun dp(value: Float) = value * resources.displayMetrics.density

    override fun onDestroy() {
        overlay?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
